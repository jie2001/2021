let path = require('path');

// console.log(__dirname); // 输出当前模块的根路径
// c:\Users\1\Desktop\day31\js

console.log(path.resolve('./A.txt'));
// 输出的是当前打开终端的路径
// C:\Users\1\Desktop\day31
// C:\Users\1\Desktop\day31\A.txt
