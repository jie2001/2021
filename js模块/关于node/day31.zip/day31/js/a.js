
let {readFile} = require('../promiseFs');

// 读取文件的时候相对的参照物是当前打开的终端的路径


// 以后写路径的时候都是以当前的项目路径作为参照物
// 切记不要以当前的文件作为参照目录
readFile('./A.txt').then((res)=>{
  // 'C:\Users\1\Desktop\day31\A.txt'
  console.log(res);
}).catch((err)=>{
  console.log(err);
})