let {a} = require('./A'); // 导入的时候后缀名可以省略(还可以进行解构)
let B = require('./A.js'); // 自定义模块(必须写路径)
let fs = require('fs'); // 内置模块(可以不写路径)
let axios = require('axios'); // 第三方模块(可以不写路径)
// console.log(fs);
console.log(axios);

// require的导入过程是同步的，当前导入没有完成，那下边的代码不会执行
// 把当前导入的模块会从头到尾执行一遍
// 如果重复导入同一个模块，那当前导入的模块只会执行一次
// 当导入的时候js文件的后缀名可以省略

// 单线程  无阻塞I/O   事件驱动

console.log(a);

