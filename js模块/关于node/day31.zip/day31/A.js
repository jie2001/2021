let a = 100;

// 想让当前模块的属性在别的地方使用，必须用module.exports去导出(exports对应的值是一个对象)

// return {
//   a
// }

module.exports = {
  a
}