const fs = require('fs');

function readFile(pathname){
  return new Promise((resolve,reject)=>{
      fs.readFile(pathname,'utf8',(err,res)=>{
          if(err !== null){
            reject(err);
            return;
          };
          resolve(res);
      })
  })
}

module.exports = {
  readFile
}



// readFile('./A.txt').then((res)=>{
//   console.log(res,18);
// }).catch((err)=>{
//   console.log(err,20);
// });



// axios.post('./xxx').then((res)=>{
//   console.log(res);
// })

// function axios(url){
//   return new Promise((resolve,reject)=>{
//     $.ajax({
//       url:url,
//       success:(res)=>{
//         resolve(res)
//       }
//     })
//   })
// }
// axios('xxx').then((res)=>{

// })